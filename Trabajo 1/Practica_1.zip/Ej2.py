import os
import numpy as np
import copy as cp
import matplotlib
matplotlib.use("Agg")  # Backend sin ventana para poder guardar la grafica
import matplotlib.pyplot as plt


#clase individuo con su array  generado aleatoriamente (1000 numeros al azar que sean 0 o 1)
class Individuo:
    def __init__(self, longitud=1000, array=None):
        if array is not None:
            self.array = array
        else:
            self.array = np.random.randint(2, size=longitud)
        self.num_unos = np.sum(self.array)
        self.probabilidad_seleccion = 0.0
        
    def contar_unos(self):
        self.num_unos = np.sum(self.array)

def asignar_probabilidades_ranking_lineal(poblacion, S=1.5):
    # Ordenar la poblacion por numero de unos de mayor a menor
    poblacion.sort(key=lambda ind: ind.num_unos, reverse=True)
    
    N = len(poblacion)
    
    # Asignar probabilidades basadas en el ranking
    for i in range(N):
        # Fórmula de ranking lineal: P(i) = (2-S)/N + 2(S-1)(N-1-i)/(N(N-1))
        prob = (2 - S) / N + (2 * (S - 1) * (N - 1 - i)) / (N * (N - 1))
        poblacion[i].probabilidad_seleccion = prob

def seleccionar_y_cruzar(poblacion):
    # Extraer probabilidades de la población actual
    probabilidades = [ind.probabilidad_seleccion for ind in poblacion]
    
    # Seleccionar 200 índices de padres (100 parejas) basándose en la probabilidad
    indices_padres = np.random.choice(len(poblacion), size=200, p=probabilidades)
    
    hijos = []
    # Iterar de 2 en 2 para formar parejas
    for i in range(0, 200, 2):
        padre1 = poblacion[indices_padres[i]]
        padre2 = poblacion[indices_padres[i+1]]
        
        # Punto de cruce aleatorio (entre 1 y longitud-1 para asegurar cruce)
        punto = np.random.randint(1, len(padre1.array))
        
        # Cruce de un punto: Hijo  toma al azar la parte izquierda de uno de los padres y la derecha del otro
        if np.random.rand() < 0.5:
            array_hijo = np.concatenate((padre1.array[:punto], padre2.array[punto:]))
            
        else:
            array_hijo = np.concatenate((padre2.array[:punto], padre1.array[punto:]))
            
        
        hijos.append(Individuo(array=array_hijo))
        
        
    return hijos

        
#crear array de 100 individuos
poblacion = [Individuo() for _ in range(100)]
mejor_individuo_global = cp.deepcopy(max(poblacion, key=lambda ind: ind.num_unos))
cont = 0
mejores_generacion = []
promedios_generacion = []

while mejor_individuo_global.num_unos < 1000 and cont < 5000: 
    
    # Ordenar y asignar probabilidades
    asignar_probabilidades_ranking_lineal(poblacion)
    
    # se guarda al mejor individuo de la generacion actual
    mejor_individuo_actual  = poblacion[0]
    mejores_generacion.append(mejor_individuo_actual.num_unos)
    promedios_generacion.append(np.mean([ind.num_unos for ind in poblacion]))
    
    #Seleccionar y cruzar
    PoblacionH = seleccionar_y_cruzar(poblacion)
    
    #mutación 
    for individuo in PoblacionH:
        mask = np.random.random(1000) < 0.001
        if np.any(mask):
            individuo.array[mask] = 1 - individuo.array[mask]  # Flip bits
            individuo.contar_unos()
            
    #aplicar elitismo: mantener el mejor individuo de la generacion actual
    PoblacionH.sort(key=lambda ind: ind.num_unos, reverse=True)
    PoblacionH[-1] = cp.deepcopy(mejor_individuo_actual)
    
    #actualizar poblacion
    poblacion = PoblacionH
    
    #actualizar mejor individuo global
    nuevo_mejor = PoblacionH[0]
    
    if nuevo_mejor.num_unos > mejor_individuo_global.num_unos:
        mejor_individuo_global = cp.deepcopy(nuevo_mejor)
        print("Iteracion numero:"+str(cont)+" Nuevo mejor individuo global con numero de unos:", mejor_individuo_global.num_unos)
     
    
    cont +=1
    
print("Mejor individuo encontrado con numero de unos:", mejor_individuo_global.num_unos, " En iteracion:", cont )

# Generar grafica fitness/generaciones segun lo pedido en el enunciado
plt.figure(figsize=(10, 5))
plt.plot(mejores_generacion, label="Mejor de la generacion")
plt.plot(promedios_generacion, label="Promedio de la poblacion")
plt.xlabel("Generaciones")
plt.ylabel("Numero de unos (fitness)")
plt.title("Evolucion del fitness (Ejercicio 2)")
plt.grid(True, linestyle="--", alpha=0.6)
plt.legend()
plt.tight_layout()
base_dir = os.path.dirname(__file__)
ruta_doc = os.path.join(base_dir, "doc")
os.makedirs(ruta_doc, exist_ok=True)
ruta_grafica = os.path.join(ruta_doc, "ej2_evolucion_fitness.png")
plt.savefig(ruta_grafica)
print("Grafica de evolucion guardada en:", ruta_grafica)
        

    
    











 
